﻿/* Bundled with offline zip */
window.CALMCLICK_CONFIG = {
  version: "1.0.0",
  chromeStoreUrl: "",
  localZipUrl: "#",
  extensionZipUrl: "#",
  githubUrl: ""
};
